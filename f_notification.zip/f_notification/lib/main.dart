import 'package:f_notification/home.dart';
import 'package:f_notification/notificationservice/local_n_service.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

Future<void> backgroundHandler(RemoteMessage message) async{
  print(message.data.toString());
  print(message.notification!.title);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(backgroundHandler);
  LocalNotificationService.initialize();            //calling initialize methode

  // final messaging = FirebaseMessaging.instance;
  //
  //  Web/iOS app users need to grant permission to receive messages
  // final settings = await messaging.requestPermission(
  //   alert: true,             notification can be displayed on screen
  //   announcement: false,
  //   badge: true,
  //   carPlay: false,
  //   criticalAlert: false,
  //   provisional: false,
  //   sound: true,
  // );
  //
  // if (kDebugMode) {
  //   print('Permission granted: ${settings.authorizationStatus}');
  // }
  //
  // // TODO: replace with your own VAPID key
  // const vapidKey = "<YOUR_PUBLIC_VAPID_KEY_HERE>";
  //
  // // TODO: Register with FCM
  // // use the registration token to send messages to users from your trusted server environment
  // String? token;
  //
  // //if (DefaultFirebaseOptions.currentPlatform == DefaultFirebaseOptions.web) {
  // token = await messaging.getToken(
  //   vapidKey: vapidKey,
  // );
  // // } else {
  // //   token = await messaging.getToken();
  // // }
  //
  //
  // if (kDebugMode) {
  //   print('Registration Token=$token');
  // }

  runApp(MyApp());
}



class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Firebase push notification',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      //  useMaterial3: true,
      ),
      initialRoute: 'home',
      routes: {
        'home' : (context) => Home()
      },
    );
  }
}

