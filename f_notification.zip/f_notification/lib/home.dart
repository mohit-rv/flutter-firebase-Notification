import 'dart:convert';
import 'package:f_notification/demo.dart';
import 'package:f_notification/notificationservice/local_n_service.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
   String deviceToken = "";


  @override
  void initState() {
    super.initState();

    // 1. This method call when app in terminated state and you get a notification
    // when you click on notification app open from terminated state and you can get notification data in this method
    FirebaseMessaging.instance.getInitialMessage().then(
          (message) {
        print("FirebaseMessaging.instance.getInitialMessage");
        if (message != null) {
          print("New Notification");
          if (message.data['_id'] != null) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => Demo(
                  id: message.data['_id'],
                ),
              ),
            );
          }
        }
      },
    );

    // 2. This method only call when App in forground it mean app must be opened
    FirebaseMessaging.onMessage.listen(
          (message) {
        print("FirebaseMessaging.onMessage.listen");
        if (message.notification != null) {
          print(message.notification!.title);
          print(message.notification!.body);
          print("message.data11 ${message.data}");
          LocalNotificationService.createanddisplaynotification(message);       //calling created channel in this

        }
      },
    );

    // 3. This method only call when App in background and not terminated(not closed)
    FirebaseMessaging.onMessageOpenedApp.listen(
          (message) {
        print("FirebaseMessaging.onMessageOpenedApp.listen");
        if (message.notification != null) {
          print(message.notification!.title);
          print(message.notification!.body);
          print("message.data22 ${message.data['_id']}");
        }
      },
    );

  }   //initstate


   Future<void> getDeviceTokenToSendNotification() async {     //for printing device token
     final FirebaseMessaging _fcm = FirebaseMessaging.instance;
     final token = await _fcm.getToken();
     deviceToken = token.toString();
     print("Token Value $deviceToken");
   }




  @override
  Widget build(BuildContext context) {

    getDeviceTokenToSendNotification();

    return Scaffold(
      appBar: AppBar(
        title: Text("Firebase Notification App"),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(0),
          child: Column(mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 110),
                child: ElevatedButton(onPressed: (){
                  sendPushNotification();


                  },
                    child: Text("Send Notification")),
              )
            ],
          )
        ),
      ),
    );
  }


   Future<void> sendPushNotification() async {
     try {
       http.Response response = await http.post(
         Uri.parse("https://fcm.googleapis.com/fcm/send"),
         headers: <String, String>{
           'Content-Type': 'application/json; charset=UTF-8',
           'Authorization': 'key=AAAAbz0hsOE:APA91bG_bi6QNNXhuiqr_C7eeKdKzP2wLHUdhWIoW_BMgeFV6wo1QJZT3z6w1iW1S8YCMvqUCY9dMZxUW56Q_muvkEzrdIUS-Qvhjgv8_gGLbZHCYuPhvfv3-FtD5p-a7mGQHzY-HD1f', //firebase server key
         },
         body: jsonEncode(
           <String, dynamic>{
             'priority': 'high',
             'notification': <String, dynamic>{
               'body': 'Mohit Verma ',
               'title': 'Incoming message',
               //'subtitle': '0863'
             },
            // 'priority': 'high',
             'data': <String, dynamic>{
               'click_action': 'FLUTTER_NOTIFICATION_CLICK',
               'id': '123456',
               'status': 'done'
             },
             'to': //'eq8XisWvRyShAPyW91kdCS:APA91bE9MOV2S2xP0g7YqsrKg4SDCt9dVSHkmoEO2bzPUwakFNRblAvv_3QENiXX8bRwDdWTcQlRt_74hRCe_CZ6Lq2tLR-dTIjDfmyN3BpkwDF0V-fjJmgu3U2UVvq_x724O8dCMrDC'
             //'d8uu5eZMQteE4VANcEiXNt:APA91bE7IKI_KNBNmN3Dz3RTsyGz98zyTOxtzFw9nWA0wfAJbEkYO5DjrloDuCnYRQRq2Tx1pEY9b-9JasYstCHVrkcJHjErA-QDcwBdhENctte7293LeEW1TrE3RE28EieeluMEBSiK'
              'depFOQCVlnuqidEdldmG8P:APA91bEshI4oubUhispHhQWQ6r2OpFZwpJGZc475KHQEWDUepeRgYpN8MofsonBXrYm5adVpYFkl54JLjYwTinQ_NSPswWyIgUeNcFTT3RQiHwQfieotGDsFZVbJfyrXBa_hgqFEPi14', //Token id of device
             //'token': authorizedSupplierTokenId
           },
         ),
       );
       response;
     } catch (e) {
       e;
     }
   }

}
